module.exports = {
  mongoURI:
    "mongodb://Luis:TEstPA$SwoRd826@ds033123.mlab.com:33123/anteater-dev"
};
